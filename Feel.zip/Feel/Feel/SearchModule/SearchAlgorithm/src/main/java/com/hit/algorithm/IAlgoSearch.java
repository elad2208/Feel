package com.hit.algorithm;

public interface IAlgoSearch {
	
	boolean Search(String pat,String txt);   
	
}
