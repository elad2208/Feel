package com.hit.algorithm;

public interface IAlgoSearch {

}


