

import com.hit.algorithm.ZSearch;

public class ServerDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ZSearch a=new ZSearch();

	}

}
