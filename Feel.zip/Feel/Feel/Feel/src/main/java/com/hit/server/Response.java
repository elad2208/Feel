package com.hit.server;

public class Response {

	public String errorResponse() {
		return "error parsing the request!";
	}
	
	public String successResponse() {
		return "successful!";
	}
	
	
	
}
