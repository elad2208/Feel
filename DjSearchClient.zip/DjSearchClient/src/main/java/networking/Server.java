package networking;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) throws IOException {
		ServerSocket server = new ServerSocket(12345);

		while(true) {
			Socket someClient = server.accept();
			new Thread(new Runnable() {					
				@Override
				public void run() {
					try {
						ObjectOutputStream output=new ObjectOutputStream(someClient.getOutputStream());
						ObjectInputStream input=new ObjectInputStream(someClient.getInputStream());
						String messageIn=(String)input.readObject();
						System.out.println("message from the client: "+messageIn);

//						output.writeObject(new StringBuilder(messageIn).reverse().toString());
						output.writeObject("Hobbit \n" +
											"The Lord of the Rings - The Fellowship of the ring \n" +
											"The Lord of the Rings - The two towers \n" + 
											"The Lord of the Rings - The return of the king \n");
						
						
						output.flush();
						output.close();
						input.close();
						someClient.close();
					} catch (Exception e) {
						System.out.println("tiered of waiting for connection");
					}

				}
			}).start();
		}
	}
}
