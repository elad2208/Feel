package networking;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Client {

	public String sendData(String data) {
		return sendRequest(data);
	}
	
	private static String sendRequest(String data) {
		String revStr = "";
		try{
			InetAddress localaddr = InetAddress.getLocalHost();

			Socket myServer = new Socket(localaddr.getHostAddress(), 12345);
			ObjectOutputStream output=new ObjectOutputStream(myServer.getOutputStream());
			ObjectInputStream input=new ObjectInputStream(myServer.getInputStream());
			
			output.writeObject(data);
			output.flush();

			revStr = (String) input.readObject();
			
			output.close();
			input.close();
			myServer.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return revStr;


	}

}
