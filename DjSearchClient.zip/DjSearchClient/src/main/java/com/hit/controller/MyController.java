/*package com.hit.controller;

import java.util.Observable;

import com.hit.model.Model;
import com.hit.model.MyModel;
import com.hit.view.MyGraphicalView;
import com.hit.view.View;

public class MyController implements IController{

	private Model model;
	private View view;
	
	public MyController(Model model, View view){
		this.view = view;
		this.model = model;
	}
	
	@Override
	public void update(Observable o, Object arg) {
		if(o instanceof View) {
			((MyModel)model).reverseString((String)arg);
		}else if(o instanceof MyModel){
			view.setReversedString((String)arg);
		}
		
	}

}
*/