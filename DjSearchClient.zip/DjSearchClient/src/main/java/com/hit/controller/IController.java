package com.hit.controller;

import java.util.Observer;

 public interface IController extends Observer{

}
