package com.hit.driver;


import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class HelloWorld{

	public static void main(String[] args) {
		Dj s = new Dj((long) 123456789,"Jhony", "Pop");
		s.hashCode();
		
		List<Integer> list = new ArrayList<>();
		System.out.println("s");
		
	}
}

    