package com.hit.driver;

public class Dj {
	private String nickName;
	private Long id;
	private String genre;
	private Boolean hired;
	private float price_hour;
	public Dj() {}
	
	public Dj(Long id, String nickName, String genre) {
		super();
		this.id = id;
		this.nickName = nickName;
		this.genre = genre;
		
	}
	
	public void setHired(Boolean hired) {
		this.hired = hired;
	}

	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}	
	
	
	
	public String getnickName() {
		return nickName;
	}

	public void setnickName(String nickName) {
		this.nickName = nickName;
	}

	public String getgenre() {
		return genre;
	}

	public void setgenre(String genre) {
		this.genre = genre;
	}

	public float getpriceperhour() {
		return price_hour;
	}

	public void setpriceperhour(float price) {
		this.price_hour = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
}