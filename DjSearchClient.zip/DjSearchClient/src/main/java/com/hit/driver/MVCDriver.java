package com.hit.driver;

import com.hit.controller.IController;
import com.hit.controller.MyController;
import com.hit.model.Model;
import com.hit.model.MyModel;
import com.hit.view.MyCLIView;
import com.hit.view.MyGraphicalView;
import com.hit.view.View;

public class MVCDriver {

		
	public static void main(String[] args) {
		
		Model model = new MyModel();
		
//		View view = new MyCLIView(System.in, System.out);
		View view = new MyGraphicalView();
		
		IController controller = new MyController(model, view);
		
		((MyModel)model).addObserver(controller);
		
		/**
		 * ADD view as observer to controller (uncomment your view)
		 */
	((MyGraphicalView)view).addObserver(controller);
//		((MyCLIView)view).addObserver(controller);
		
		view.start();
	}

}
