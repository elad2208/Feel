package com.hit.view;


/*
 * TextAreaDemo.java requires no other files.
 */

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ListPanel extends JPanel implements ActionListener {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MyGraphicalView gui;
	
	protected JButton b1;
	private JLabel jLabel1;
	private JScrollPane jScrollPane1;
	private JTextArea textArea;

	public ListPanel(MyGraphicalView gui) {
		this.gui = gui;
		initComponents();
	}


	private void initComponents() {
		setPreferredSize(new Dimension(200, 300));
		setLayout(new FlowLayout());
		jLabel1 = new JLabel("Get data by clicking the button");
		b1 = new JButton("Send");
		textArea = new JTextArea("A text area is a \"plain\" text component, " +
			    "which means that although it can display text " +
			    "in any font, all of the text is in the same font.");
		
		textArea.setColumns(20);
		textArea.setLineWrap(true);
		textArea.setRows(5);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		
		jScrollPane1 = new JScrollPane(textArea);

		b1.setVerticalTextPosition(AbstractButton.CENTER);
		b1.addActionListener(this);
		
		add(jLabel1);
		add(jScrollPane1);
		add(b1);

	}
	// Listener methods


	@Override
	public void actionPerformed(ActionEvent e) {
		gui.setUserInput("action");
	}

	public void setReversedUserInput(String arg) {
		textArea.setText(arg);
	}

}
