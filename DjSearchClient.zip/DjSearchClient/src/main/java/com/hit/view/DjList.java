package com.hit.view;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
public class DjList
{
	public DjList()
	{
		// TODO Auto-generated method stub
		JFrame frame = new JFrame("Dj list");

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JMenuBar menuBar = new JMenuBar();

		JMenu startMenu = new JMenu("Home");

		JButton btn = new JButton("Home");
		btn.addActionListener(new ActionListener() {

		    @Override
		    public void actionPerformed(ActionEvent e) {
		    	Welcome w = new Welcome(); 
		    }
		});
		menuBar.add(btn);

		JMenu fileMenu = new JMenu("Clubber");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		menuBar.add(fileMenu);
		JMenuItem menuItem1 = new JMenuItem("See Djs list", KeyEvent.VK_N);
		fileMenu.add(menuItem1);
		JMenuItem menuItem2 = new JMenuItem("Hire Dj", KeyEvent.VK_O);
		fileMenu.add(menuItem2);

		JMenu editMenu = new JMenu("Dj");
		editMenu.setMnemonic(KeyEvent.VK_E);
		menuBar.add(editMenu);
		JMenuItem menuItem3 = new JMenuItem("Add Dj", KeyEvent.VK_F);
		editMenu.add(menuItem3);
		frame.setJMenuBar(menuBar);
		frame.setSize(550, 350);
		frame.setVisible(true);

		JLabel label2,label3;

		label2 = new JLabel("Let's See all  the djs! \r\n"
				+ "\n");
		label3 = new JLabel("  -open djlist.txt under DjSearchClient, \r\n"
				+ "and choose one.\r\n"
				+ "\n");

		label2.setFont(new Font("Arial", Font.BOLD, 18));
		label3.setFont(new Font("Arial", Font.PLAIN, 12));


		frame.getContentPane().add(label2);
		frame.getContentPane().add(label3);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));



		JPanel panel = new JPanel();
		JButton btn1 = new JButton("Hire Dj");
		btn1.addActionListener(new ActionListener() {

		    @Override
		    public void actionPerformed(ActionEvent e) {
		    	SearchBox f = new SearchBox("Find Dj");
		    }
		});
		panel.add(btn1);
		panel.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.setPreferredSize(new Dimension(100, 500));
		panel.setMaximumSize(new Dimension(100, 500));
		frame.getContentPane().add(panel);
		frame.setSize(550, 300);
		frame.setVisible(true);


		frame.setLayout(new FlowLayout());
		frame.setSize(350,300);


		frame.setVisible(true);



				JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

				int returnValue = jfc.showOpenDialog(null);
				// int returnValue = jfc.showSaveDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = jfc.getSelectedFile();
					System.out.println(selectedFile.getAbsolutePath());
				

			}

		}
	
public static void main(String[] args)
{
    
	DjList f=new DjList();


}

}
