package com.hit.view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.hit.algorithm.ZSearch;

 
public class SearchBox extends JFrame {
    private static JTextField searchable = new JTextField(30);
    private JButton searchB = new JButton("Search");
    private JTable result = new JTable();
    private JPanel panel = new JPanel();
    private JScrollPane scrollPane = new JScrollPane(result);
    private Container c;
  
    public static String djs[]
    	    = { "nissim"," rlad","meital","miko",
    	    		"libi", "avi", " sami", "golan",
    	        "mike99","roni", " eli" };
    
    public static void main(String[] args) {
        new SearchBox("Find Dj");
        ZSearch a=new ZSearch();
        for(int i=0;i<=djs.length+1;i++)
        	a.Search(djs[0], searchable.getText());
        	
        
        
    }
 
    public SearchBox(String title) throws HeadlessException {
        
    	super(title);
	
        setSize(600, 600);
        setResizable(true);
        addComponents();
        setTable();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        
        
    }
 
    private void addComponents() {
        panel.add(searchable);
        panel.add(searchB);
        panel.add(scrollPane);
        add(panel);
    }
 
    private void setTable() {
        
    }
}