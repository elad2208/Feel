package com.hit.view;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class AddDj extends JFrame
implements ActionListener {
	 
// Components of the Form
private Container c;
private JLabel title;
private JLabel nickName;
private JTextField tnickName;
private JLabel mno;
private JTextField tmno;
private JLabel Hired;
private JRadioButton busy;
private JRadioButton available;
private ButtonGroup gengp;
private JLabel genre;
private JComboBox music;

private JLabel price;
private JTextArea tprice;
private JCheckBox term;
private JButton sub;
private JButton reset;
private JTextArea tout;
private JLabel res;
private JTextArea resadd;

private String musics[]
    = { "All","American","Arabic","Blues",
    		"Country", "Dance", "Hip Hop", "Israeli",
        "Jazz","K-pop", "Middle east", "Pop",
        "Rock and Roll", "Soul" };

// constructor, to initialize the components
// with default values.
public AddDj()
{
    setTitle("Add new Dj");
    setBounds(30, 180, 900, 600);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setResizable(false);

    c = getContentPane();
    c.setLayout(null);

    title = new JLabel("Registration Form");
    title.setFont(new Font("Arial", Font.PLAIN, 30));
    title.setSize(300, 30);
    title.setLocation(300, 30);
    c.add(title);

 // TODO Auto-generated method stub
    JFrame frame = new JFrame("Add Dj");
    frame.setResizable(false);

    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JMenuBar menuBar = new JMenuBar();
    
    JButton btn1 = new JButton("Home");
	btn1.addActionListener(new ActionListener() {

	    @Override
	    public void actionPerformed(ActionEvent e) {
	    	Welcome w = new Welcome(); 
	    }
	});
	menuBar.add(btn1);
	
	

    JMenu fileMenu = new JMenu("Clubber");
    fileMenu.setMnemonic(KeyEvent.VK_F);
    menuBar.add(fileMenu);
    JMenuItem menuItem1 = new JMenuItem("See Djs list", KeyEvent.VK_N);
    fileMenu.add(menuItem1);
    JMenuItem menuItem2 = new JMenuItem("Hire Dj", KeyEvent.VK_O);
    fileMenu.add(menuItem2);

    JMenu editMenu = new JMenu("Dj");
    editMenu.setMnemonic(KeyEvent.VK_E);
    menuBar.add(editMenu);
    JMenuItem menuItem3 = new JMenuItem("Add Dj", KeyEvent.VK_F);
    editMenu.add(menuItem3);
    frame.setJMenuBar(menuBar);
    frame.setSize(550, 350);
    frame.setVisible(true);


    JLabel label,label2;
    label = new JLabel("Hey there!");
    label2 = new JLabel("In order to add yourself, please fill the next details: ");
    label.setFont(new Font("Arial", Font.BOLD, 18));
    label2.setFont(new Font("Arial", Font.BOLD, 12));
    label.setVerticalAlignment(JLabel.CENTER);

    frame.add(label);
    frame.getContentPane().add(label);
    frame.getContentPane().add(label2);

    frame.setLayout(new FlowLayout());
    frame.setSize(350,300);


    frame.setVisible(true);
    nickName = new JLabel("NickName");
    nickName.setFont(new Font("Arial", Font.PLAIN, 20));
    nickName.setSize(100, 20);
    nickName.setLocation(100, 100);
    c.add(nickName);

    tnickName = new JTextField();
    tnickName.setFont(new Font("Arial", Font.PLAIN, 15));
    tnickName.setSize(190, 20);
    tnickName.setLocation(200, 100);
    c.add(tnickName);

    mno = new JLabel("ID");
    mno.setFont(new Font("Arial", Font.PLAIN, 20));
    mno.setSize(100, 20);
    mno.setLocation(100, 150);
    c.add(mno);

    tmno = new JTextField();
    tmno.setFont(new Font("Arial", Font.PLAIN, 15));
    tmno.setSize(150, 20);
    tmno.setLocation(200, 150);
    c.add(tmno);

    Hired = new JLabel("Hired?");
    Hired.setFont(new Font("Arial", Font.PLAIN, 20));
    Hired.setSize(100, 20);
    Hired.setLocation(100, 200);
    c.add(Hired);

    busy = new JRadioButton("busy");
    busy.setFont(new Font("Arial", Font.PLAIN, 13));
    busy.setSelected(true);
    busy.setSize(75, 20);
    busy.setLocation(200, 200);
    c.add(busy);

    available = new JRadioButton("available");
    available.setFont(new Font("Arial", Font.PLAIN, 13));
    available.setSelected(false);
    available.setSize(80, 20);
    available.setLocation(275, 200);
    c.add(available);

    gengp = new ButtonGroup();
    gengp.add(busy);
    gengp.add(available);

    genre = new JLabel("Genre");
    genre.setFont(new Font("Arial", Font.PLAIN, 20));
    genre.setSize(100, 20);
    genre.setLocation(100, 250);
    c.add(genre);

    music = new JComboBox(musics);
    music.setFont(new Font("Arial", Font.PLAIN, 15));
    music.setSize(150, 30);
    music.setLocation(200, 250);
    c.add(music);

    price = new JLabel("Price");
    price.setFont(new Font("Arial", Font.PLAIN, 20));
    price.setSize(100, 20);
    price.setLocation(100, 300);
    c.add(price);

    tprice = new JTextArea();
    tprice.setFont(new Font("Arial", Font.PLAIN, 15));
    tprice.setSize(150, 20);
    tprice.setLocation(200, 300);
    tprice.setLineWrap(true);
    c.add(tprice);

    term = new JCheckBox("Accept Terms And Conditions.");
    term.setFont(new Font("Arial", Font.PLAIN, 15));
    term.setSize(250, 20);
    term.setLocation(150, 400);
    c.add(term);

    sub = new JButton("Submit");
    sub.setFont(new Font("Arial", Font.PLAIN, 15));
    sub.setSize(100, 20);
    sub.setLocation(150, 450);
    sub.addActionListener(this);
    c.add(sub);

    reset = new JButton("Reset");
    reset.setFont(new Font("Arial", Font.PLAIN, 15));
    reset.setSize(100, 20);
    reset.setLocation(270, 450);
    reset.addActionListener(this);
    c.add(reset);

    tout = new JTextArea();
    tout.setFont(new Font("Arial", Font.PLAIN, 15));
    tout.setSize(300, 400);
    tout.setLocation(500, 100);
    tout.setLineWrap(true);
    tout.setEditable(false);
    c.add(tout);

    res = new JLabel("");
    res.setFont(new Font("Arial", Font.PLAIN, 20));
    res.setSize(500, 25);
    res.setLocation(100, 500);
    c.add(res);

    resadd = new JTextArea();
    resadd.setFont(new Font("Arial", Font.PLAIN, 15));
    resadd.setSize(200, 75);
    resadd.setLocation(580, 175);
    resadd.setLineWrap(true);
    c.add(resadd);

    setVisible(true);
    
  //create djlist
    try {
        File myObj = new File("djlist.txt");
        if (myObj.createNewFile()) {
          System.out.println("File created: " + myObj.getName());
        } else {
          System.out.println("File already exists.");
        }
      } catch (IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
    
    
}

// method actionPerformed()
// to get the action performed
// by the user and act accordingly
public void actionPerformed(ActionEvent e)
{
    if (e.getSource() == sub) {
        if (term.isSelected()) {
            String data1;
            
            if(tnickName.getText().equals(""))
            	{
            	tout.setText("");
                resadd.setText("");
                	res.setText("invalid nickname..");
            	return;
            	}
            	
            if(tmno.getText().length()!=9)
        	{
        	tout.setText("");
            resadd.setText("");
            	res.setText("invalid id..(9 digits)");
        	return;
        	}
            
            if(tprice.getText().equals(""))
        	{
        	tout.setText("");
            resadd.setText("");
            	res.setText("invalid price..(not empty)");
        	return;
        	}
            String data
                = "nickName : "
                  + tnickName.getText() + "\n"
                  + "ID : "
                  + tmno.getText() + "\n";
            if (busy.isSelected())
                data1 = "Hired : busy"
                        + "\n";
            else
                data1 = "Hired : available"
                        + "\n";
            String data2
                = "genre : "
                  + (String)music.getSelectedItem()
                  + "\n";

            String data3 = "Price : " + tprice.getText();
            tout.setText(data + data1 + data2 + data3);
            tout.setEditable(false);
            res.setText("Registration Successfully..");
            
            
          //write to file
            try
            {
                String filename= "djlist.txt";
                FileWriter fw = new FileWriter(filename,true); //the true will append the new data
                fw.write("\n"+data + data1 + data2 + data3+"\n");//appends the string to the file
                fw.close();
                               
            }
            catch(IOException ioe)
            {
                System.err.println("IOException: " + ioe.getMessage());
            }
                      
        }
        else {
            tout.setText("");
            resadd.setText("");
            res.setText("Please accept the"
                        + " terms & conditions..");
        }
    }

    else if (e.getSource() == reset) {
        String def = "";
        tnickName.setText(def);
        tprice.setText(def);
        tmno.setText(def);
        res.setText(def);
        tout.setText(def);
        term.setSelected(false);
        music.setSelectedIndex(0);
        resadd.setText(def);
    }
}



    public static void main(String[] args) throws Exception
    {
    	
        AddDj f = new AddDj();
       
     
        
    }




}
