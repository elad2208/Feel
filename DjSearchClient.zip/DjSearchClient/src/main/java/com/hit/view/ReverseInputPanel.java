/*package com.hit.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ReverseInputPanel extends JPanel implements ActionListener{

	protected JButton b1;
	protected JTextField input;
	protected MyGraphicalView gui;
	JLabel labal;
	
	public ReverseInputPanel(MyGraphicalView gui) {
		this.gui = gui;
		b1 = new JButton("Click me");
		input = new JTextField("input text");
		labal = new JLabel();
		b1.addActionListener(this);
		add(b1);
		add(input);
		add(labal);
		
	}
	public void actionPerformed(ActionEvent e) {		
		gui.setUserInput(input.getText());
	}
	public void setReversedUserInput(String arg) {
		input.setText(arg);
		labal.setText(arg);
		
	}
}
*/