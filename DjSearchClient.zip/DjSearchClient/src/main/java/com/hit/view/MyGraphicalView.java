package com.hit.view;

import java.awt.Dimension;
import java.util.Observable;

import javax.swing.JFrame;

public class MyGraphicalView extends Observable implements View {

	private ReverseInputPanel inputPanel; 
	private ListPanel listPanel;
	
	@Override
	public void start() {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});

	}

	protected void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("My Frame");
        frame.setPreferredSize(new Dimension(400, 500));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Create and set up the content pane.
//        inputPanel = new ReverseInputPanel(this); 
//        frame.getContentPane().add(inputPanel);
        
        listPanel = new ListPanel(this);
        frame.getContentPane().add(listPanel);
        
        //Display the window.
        frame.pack();
        frame.setVisible(true);

		
	}

	public void setReversedString(String str) {
		listPanel.setReversedUserInput(str);
//		inputPanel.setReversedUserInput(str);
	}

	public void setUserInput(String text) {
		setChanged();
		notifyObservers(text);
	}


}
