package com.hit.view;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Observable;
import java.util.Scanner;

public class MyCLIView extends Observable implements View, Runnable{

	private Scanner input;
    private PrintWriter output;

    public MyCLIView(InputStream in, OutputStream out) {
        input = new Scanner(in);
        output = new PrintWriter(out);
    }

    @Override
    public void run() {
        String clientInput = null;
        while (true) {
            clientInput = input.nextLine();
            setChanged();
    		notifyObservers(clientInput);
        }
    }

    public void setReversedString(String arg) {
		this.write(arg);

	}
    
    public void write(String string) {
        output.println(string);
        output.flush();
    }


	@Override
	public void start() {
		new Thread(this).start();
		
	}

}
