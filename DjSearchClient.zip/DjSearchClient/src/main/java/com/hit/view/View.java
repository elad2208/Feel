package com.hit.view;

public interface View {

	void start();
	void setReversedString(String arg);
	
}
