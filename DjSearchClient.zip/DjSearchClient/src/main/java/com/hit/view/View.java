package com.hit.view;

import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public interface View {

	void start();
	void setReversedString(String arg);
	
}
