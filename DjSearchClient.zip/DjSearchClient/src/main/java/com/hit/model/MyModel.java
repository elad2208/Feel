package com.hit.model;

import java.util.Observable;

import networking.Client;

public class MyModel extends Observable implements Model {

	Client client = new Client();
	
	public void reverseString(String arg) {
		setChanged();
		notifyObservers(client.sendData(arg));		
	}

	
}
