package com.hit.model;

import java.util.List;

public interface Model {

	
}
